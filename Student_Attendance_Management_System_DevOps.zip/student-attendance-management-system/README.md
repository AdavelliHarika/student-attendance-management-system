# Student Attendance Management System

A full-stack attendance website built with React, Node.js, Express and MongoDB. Docker Compose starts the frontend, backend and database together. A GitHub Actions workflow builds the React app on pushes and pull requests.

## Features
- Add students with name, roll number, department and year
- Prevent duplicate roll numbers
- Mark Present or Absent for a selected date
- Search student records
- Dashboard summary for total students, present and absent today
- Delete students and their attendance records
- MongoDB persistence
- Docker Compose setup and GitHub Actions CI workflow

## Run with Docker (recommended)
Requirements: Docker Desktop installed and running.

1. Extract this ZIP.
2. Open the extracted `student-attendance-management-system` folder in VS Code.
3. Open Terminal in VS Code.
4. Run:

   ```bash
   docker compose up --build
   ```

5. Open the website: http://localhost:3000
6. Backend health check: http://localhost:5000/api/health

Stop the project with `Ctrl + C`, then run `docker compose down`. MongoDB data remains in the named Docker volume. To remove the database volume too, run `docker compose down -v` (this permanently deletes the stored local database).

## Run without Docker
Requirements: Node.js 20+ and MongoDB running locally.

1. Start MongoDB on your computer.
2. In the project root, install the helper dependency:

   ```bash
   npm install
   npm install --prefix server
   npm install --prefix client
   ```
3. Start the backend in terminal 1:

   ```bash
   cd server
   npm run dev
   ```

4. Start the frontend in terminal 2:

   ```bash
   cd client
   npm run dev
   ```

5. Open the local Vite URL shown in the terminal (normally http://localhost:5173).

The backend defaults to `mongodb://127.0.0.1:27017/student_attendance`. For Docker Compose it uses the internal MongoDB service hostname.

## Useful commands
- `docker compose up --build` — build and start all containers
- `docker compose ps` — see container status
- `docker compose logs -f` — view logs
- `docker compose down` — stop and remove containers/network
- `docker compose down -v` — stop and delete containers plus database volume

## Project structure
```text
student-attendance-management-system/
├── client/                 # React + Vite frontend, served by Nginx in Docker
├── server/                 # Express REST API + Mongoose models
├── .github/workflows/      # GitHub Actions CI pipeline
├── docker-compose.yml      # MongoDB, backend and frontend services
├── .env.example
└── README.md
```

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API health check |
| GET | `/api/students` | List students |
| POST | `/api/students` | Add student |
| DELETE | `/api/students/:id` | Delete student |
| GET | `/api/attendance?date=YYYY-MM-DD` | Attendance for a date |
| POST | `/api/attendance` | Create/update attendance |
| GET | `/api/summary` | Dashboard counts |

## DevOps notes
This project demonstrates containerization with separate frontend/backend images, service orchestration with Docker Compose, persistent MongoDB storage through a named volume, and CI build validation with GitHub Actions.

## Important
This is an educational starter project. It does not include login, role-based access control, production deployment, or a hosted public URL. `localhost` is only accessible from your computer. To publish it, deploy the containers to a hosting provider and configure environment variables, HTTPS, and database security.

import { useEffect, useMemo, useState } from "react";
import { Users, UserCheck, UserX, GraduationCap, Plus, Trash2, CalendarDays, Search, RefreshCw } from "lucide-react";

const today = new Date().toISOString().slice(0, 10);
const api = async (path, options = {}) => {
  const response = await fetch(`/api${path}`, { headers: { "Content-Type": "application/json" }, ...options });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Request failed");
  return data;
};

export default function App() {
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [summary, setSummary] = useState({ students: 0, presentToday: 0, absentToday: 0 });
  const [date, setDate] = useState(today);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ name: "", rollNumber: "", department: "CSE", year: "1" });
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const [s, a, stats] = await Promise.all([api("/students"), api(`/attendance?date=${date}`), api("/summary")]);
      setStudents(s); setAttendance(a); setSummary(stats); setMessage("");
    } catch (e) { setMessage(e.message); }
  }
  useEffect(() => { load(); }, [date]);

  const marked = useMemo(() => new Map(attendance.map(a => [a.student?._id, a.status])), [attendance]);
  const filtered = students.filter(s => `${s.name} ${s.rollNumber} ${s.department}`.toLowerCase().includes(search.toLowerCase()));

  async function addStudent(e) {
    e.preventDefault(); setBusy(true);
    try {
      await api("/students", { method: "POST", body: JSON.stringify(form) });
      setForm({ name: "", rollNumber: "", department: "CSE", year: "1" });
      setMessage("Student added successfully."); await load();
    } catch (e) { setMessage(e.message); }
    finally { setBusy(false); }
  }
  async function mark(studentId, status) {
    try {
      await api("/attendance", { method: "POST", body: JSON.stringify({ studentId, date, status }) });
      await load();
    } catch (e) { setMessage(e.message); }
  }
  async function remove(id) {
    if (!window.confirm("Delete this student and their attendance records?")) return;
    try { await api(`/students/${id}`, { method: "DELETE" }); await load(); }
    catch (e) { setMessage(e.message); }
  }

  return <main className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><GraduationCap size={23}/></div><span>Attend<span className="brand-accent">Ease</span></span></div>
      <div className="nav-active"><Users size={18}/> Dashboard</div>
      <div className="side-note">DEVOPS PROJECT<br/><b>Student Attendance</b></div>
      <div className="side-bottom"><span className="status-dot"/> MongoDB workspace</div>
    </aside>
    <section className="main">
      <header className="topbar"><div><div className="eyebrow">OVERVIEW</div><h1>Attendance Dashboard</h1><p className="sub">Manage students and track daily attendance.</p></div><button className="refresh" onClick={load}><RefreshCw size={16}/> Refresh</button></header>
      {message && <div className="notice">{message}<button onClick={() => setMessage("")}>×</button></div>}
      <div className="stats">
        <Stat icon={<Users/>} label="Total Students" value={summary.students} tone="blue"/>
        <Stat icon={<UserCheck/>} label="Present Today" value={summary.presentToday} tone="green"/>
        <Stat icon={<UserX/>} label="Absent Today" value={summary.absentToday} tone="red"/>
      </div>
      <div className="content-grid">
        <section className="panel add-panel">
          <div className="panel-heading"><div><h2>Add Student</h2><p>Register a student in your class</p></div><div className="mini-icon"><Plus size={18}/></div></div>
          <form onSubmit={addStudent} className="student-form">
            <label>Student name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Enter full name"/></label>
            <label>Roll number<input required value={form.rollNumber} onChange={e=>setForm({...form,rollNumber:e.target.value})} placeholder="e.g. 23CS001"/></label>
            <div className="form-row"><label>Department<select value={form.department} onChange={e=>setForm({...form,department:e.target.value})}><option>CSE</option><option>IT</option><option>ECE</option><option>EEE</option><option>MECH</option><option>CIVIL</option></select></label><label>Year<select value={form.year} onChange={e=>setForm({...form,year:e.target.value})}>{["1","2","3","4"].map(y=><option key={y} value={y}>{y}</option>)}</select></label></div>
            <button className="primary" disabled={busy}><Plus size={17}/> {busy ? "Adding..." : "Add Student"}</button>
          </form>
        </section>
        <section className="panel attendance-panel">
          <div className="panel-heading"><div><h2>Daily Attendance</h2><p>Choose a date and mark each student</p></div><div className="mini-icon"><CalendarDays size={18}/></div></div>
          <label className="date-label">Attendance date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label>
          <div className="attendance-summary"><div><b>{attendance.length}</b><span>Marked</span></div><div><b>{students.length - attendance.length}</b><span>Pending</span></div><div><b>{students.length ? Math.round((attendance.filter(a=>a.status==="Present").length/students.length)*100) : 0}%</b><span>Present rate</span></div></div>
          <p className="hint">Use the buttons in the student list to update attendance.</p>
        </section>
      </div>
      <section className="panel table-panel">
        <div className="table-heading"><div><h2>Student Records</h2><p>{students.length} registered students</p></div><div className="search"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search students..."/></div></div>
        <div className="table-wrap"><table><thead><tr><th>STUDENT</th><th>ROLL NUMBER</th><th>DEPARTMENT</th><th>YEAR</th><th>ATTENDANCE · {date}</th><th></th></tr></thead><tbody>
          {filtered.map(s=><tr key={s._id}><td><div className="student-cell"><div className="avatar">{s.name.slice(0,1).toUpperCase()}</div><b>{s.name}</b></div></td><td>{s.rollNumber}</td><td>{s.department}</td><td>{s.year}</td><td><div className="actions"><button className={`mark present ${marked.get(s._id)==="Present"?"selected":""}`} onClick={()=>mark(s._id,"Present")}>Present</button><button className={`mark absent ${marked.get(s._id)==="Absent"?"selected":""}`} onClick={()=>mark(s._id,"Absent")}>Absent</button></div></td><td><button className="delete" title="Delete student" onClick={()=>remove(s._id)}><Trash2 size={16}/></button></td></tr>)}
          {!filtered.length && <tr><td colSpan="6" className="empty">{students.length ? "No matching students found." : "No students yet. Add your first student above."}</td></tr>}
        </tbody></table></div>
      </section>
      <footer>AttendEase <span>•</span> React + Node.js + Express + MongoDB <span>•</span> Docker-ready DevOps project</footer>
    </section>
  </main>;
}

function Stat({icon,label,value,tone}) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div><p>{label}</p><strong>{value}</strong></div></div>;
}

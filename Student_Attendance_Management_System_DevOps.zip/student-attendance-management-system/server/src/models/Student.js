import mongoose from "mongoose";

const studentSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  rollNumber: { type: String, required: true, unique: true, trim: true },
  department: { type: String, default: "CSE" },
  year: { type: String, default: "1" }
}, { timestamps: true });

export default mongoose.model("Student", studentSchema);

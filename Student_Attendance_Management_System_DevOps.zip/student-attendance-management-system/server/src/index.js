import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import Student from "./models/Student.js";
import Attendance from "./models/Attendance.js";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "attendance-api" }));

app.get("/api/students", async (_req, res) => {
  try { res.json(await Student.find().sort({ rollNumber: 1 })); }
  catch (error) { res.status(500).json({ message: error.message }); }
});

app.post("/api/students", async (req, res) => {
  try {
    const { name, rollNumber, department, year } = req.body;
    if (!name?.trim() || !rollNumber?.trim()) return res.status(400).json({ message: "Name and roll number are required." });
    const student = await Student.create({ name, rollNumber, department, year });
    res.status(201).json(student);
  } catch (error) {
    res.status(error.code === 11000 ? 409 : 500).json({ message: error.code === 11000 ? "Roll number already exists." : error.message });
  }
});

app.delete("/api/students/:id", async (req, res) => {
  try {
    await Student.findByIdAndDelete(req.params.id);
    await Attendance.deleteMany({ student: req.params.id });
    res.json({ message: "Student deleted." });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

app.get("/api/attendance", async (req, res) => {
  try {
    const date = req.query.date || new Date().toISOString().slice(0, 10);
    const records = await Attendance.find({ date }).populate("student").sort({ createdAt: -1 });
    res.json(records);
  } catch (error) { res.status(500).json({ message: error.message }); }
});

app.post("/api/attendance", async (req, res) => {
  try {
    const { studentId, date, status } = req.body;
    if (!studentId || !date || !["Present", "Absent"].includes(status)) return res.status(400).json({ message: "Valid student, date and status are required." });
    const record = await Attendance.findOneAndUpdate(
      { student: studentId, date },
      { status },
      { new: true, upsert: true, runValidators: true }
    ).populate("student");
    res.json(record);
  } catch (error) { res.status(500).json({ message: error.message }); }
});

app.get("/api/summary", async (_req, res) => {
  try {
    const [students, presentToday, absentToday] = await Promise.all([
      Student.countDocuments(),
      Attendance.countDocuments({ date: new Date().toISOString().slice(0, 10), status: "Present" }),
      Attendance.countDocuments({ date: new Date().toISOString().slice(0, 10), status: "Absent" })
    ]);
    res.json({ students, presentToday, absentToday });
  } catch (error) { res.status(500).json({ message: error.message }); }
});

const port = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/student_attendance")
  .then(() => app.listen(port, () => console.log(`API running on port ${port}`)))
  .catch(error => { console.error("MongoDB connection failed:", error.message); process.exit(1); });
